<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Registrasi Santri Baru</title>
</head>
<h2>Form Pendaftaran Santri Baru</h2>

<body>
    <form method="post" action="simpan.php">
        <table>
            <tr>
                <td>idsantri</td>
                <td>:</td>
                <td><input type="text" name="idsantri" placeholder="Input idsantri" /></td>
            </tr>
            <tr>
                <td>Nama</td>
                <td>:</td>
                <td><input type="text" name="nama" placeholder="Input Nama" /></td>
            </tr>
            <tr>
                <td>Tempat & Tanggal Lahir</td>
                <td>:</td>
                <td><input type="text" name="tempattanggallahir" placeholder="Input Tempat & Tanggal Lahir" /></td>
            </tr>
            <tr>
                <td>Alamat</td>
                <td>:</td>
                <td><input type="text" name="alamat" placeholder="Input Alamat" /></td>
            </tr>
            <tr>
                <td>Jenis Tinggal</td>
                <td>:</td>
                <td>
                    <select name="jenistinggal">
                        <option value="mondok">Mondok</option>
                        <option value="ngalong">Ngalong</option>
                        <option value="mengajisaja">Mengaji Saja</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td colspan="2"><button type="submit" name="submit">Registrasi</td>
            </tr>
        </table>
    </form>
</body>

</html>