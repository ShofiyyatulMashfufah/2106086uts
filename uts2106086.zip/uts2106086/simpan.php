<?php
include 'koneksi.php';
$idsantri = $_POST['idsantri'];
$nama = $_POST['nama'];
$ttl = $_POST['tempattanggallahir'];
$alamat = $_POST['alamat'];
$jenistinggal = $_POST['jenistinggal'];

$simpandata = "INSERT INTO registrasisantri (idsantri,nama,tempattanggallahir,alamat,jenistinggal) values ('$idsantri','$nama','$ttl','$alamat','$jenistinggal')";
mysqli_query($koneksi, $simpandata);

header("location: ./index.php");
exit;
