<?php
$server = 'localhost';
$user = 'root';
$pwd = '';
$database = '2106086shofiyyatul';

$koneksi = mysqli_connect($server, $user, $pwd, $database);
mysqli_select_db($koneksi, $database);
