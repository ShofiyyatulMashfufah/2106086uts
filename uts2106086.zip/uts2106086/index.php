<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Pesantren At-Taufiq</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous" />
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg bg-success">
        <div class="container">
            <a class="navbar-brand" href="#">Pesantren At-Taufiq</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">About</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"> Registrasi </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="formregistrasi.php">Form Registrasi Santri</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Navbar Akhir -->
    <!-- data pengembang -->

    <div class="jumbotron text-center">
        <img src="attaufiq.jpg" alt="At-Taufiq" width="150px" class="rounded-circle img-thumbnail" />

        <h1 class="display-8">Informasi Pesantren At-Taufiq</h1>
        <p class="lead">Pondok Pesantren At-Taufiq Lembur Sawah adalah Pondok Pesanten Ahlus-Sunnah wal-Jama'ah yang berada di Kp.Lembursawah Rt.02 Rw.01 Ds.Girimukti Kec.Cibatu Garut, Jawa Barat. <br /> Kami berkomitmen untuk menjadi wadah pendidikan dengan pola pendidikan Mu’allimin, yakni pola pendidikan pesantren yang bersifat integratif dengan memandukan antara ilmu agama islam dengan ilmu umum yang bersifat kompherensif dengan memadukan intra, ekstra, dan kokurikuler kepada para santri.</p>
        <a class="btn btn-primary btn-lg" href="#" role="button">Detail</a>
    </div>
    <!-- Data Pengembang -->

    <!-- About -->

    <div class="container text-center">
        <div class="row">
            <div class="col">
                <h2>About Me</h2>
            </div>
        </div>
    </div>
    <div class="container text-center">
        <div class="row">
            <div class="col">
                <img src="santri1.jpg" alt="Software" width="150" />
            </div>
            <div class="col">
                <img src="santrii2.jpg" alt="Hardware" width="150" />
            </div>
            <div class="col">
                <img src="santriii3.jpg" alt="Hardware" width="150" />
            </div>
        </div>
        <!-- Akhir About -->

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
</body>

</html>